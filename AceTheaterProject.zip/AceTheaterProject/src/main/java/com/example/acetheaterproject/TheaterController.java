package com.example.acetheaterproject;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;

public class TheaterController {

    @FXML private ImageView mainImage;
    @FXML private Label descriptionLabel;

    @FXML
    private void initialize() {
        try {
            String imagePath = "theater_hall.jpg";
            if (AceTheaterApp.class.getResource(imagePath) != null) {
                mainImage.setImage(new Image(AceTheaterApp.class.getResource(imagePath).toExternalForm()));
            } else {
                System.out.println("Warning: Image " + imagePath + " not found.");
            }
        } catch (Exception e) {
            System.out.println("Error loading theater image: " + e.getMessage());
        }

        if (descriptionLabel != null) {
            descriptionLabel.setText(
                    "Welcome to Ace Theater, the jewel of modern performance arts. " +
                            "Ace Theater is a striking centerpiece of the city’s cultural scene, known for its bold illuminated marquee and ultra-modern facade, which blend glass, stone, and dynamic architectural lines into a truly iconic visual experience. Established in 2011, the theater has steadily grown to become a premiere destination for live performances, from musicals and plays to independent film screenings and major award ceremonies, drawing audiences from across the region. Inside, visitors enjoy state-of-the-art acoustics\n" +
                            " and seating for over 500 guests, with every event enhanced by advanced lighting and sound technology. The building itself was designed by the renowned architect Nikki Nela, who aimed to create a space where innovation and community could flourish side by side. \n" +
                            "Ace Theater is also home to an annual arts festival, workshops for aspiring local artists, and a welcoming café that opens onto a spacious plaza—making it the heart of unforgettable evenings and creative gathering in the city."
            );
        }
    }

    @FXML
    private void onMenuClick(javafx.scene.input.MouseEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(AceTheaterApp.class.getResource("main-menu.fxml"));
        javafx.scene.Parent root = loader.load();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        currentStage.getScene().setRoot(root);
        currentStage.setTitle("Ace Theater");
    }

    @FXML
    private void onReserveClick(javafx.scene.input.MouseEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(AceTheaterApp.class.getResource("reservation-choice.fxml"));
        javafx.scene.Parent root = loader.load();

        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.getScene().setRoot(root);
        currentStage.setTitle("Ace Theater - Reserve Seats");
    }
}
