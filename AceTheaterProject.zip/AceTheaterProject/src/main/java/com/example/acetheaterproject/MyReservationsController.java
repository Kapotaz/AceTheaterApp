package com.example.acetheaterproject;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.scene.Parent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MyReservationsController {

    @FXML private ListView<String> reservationsListView;
    @FXML private VBox emptyPlaceholder;

    private static final String BG_COLOR = "#2a0a0a"; // Σκούρο φόντο (luxury dark)
    private static final String TEXT_COLOR_GOLD = "#FFD700"; // Χρυσό για τίτλους
    private static final String TEXT_COLOR_WHITE = "#fdf5e6"; // Υπόλευκο για κείμενο (Old Lace)
    private static final String BTN_COLOR_GOLD = "#d4af37"; // Χρυσό κουμπί

    public static ObservableList<String> allReservations = FXCollections.observableArrayList();

    @FXML
    private void initialize() {
        reservationsListView.setItems(allReservations);
        updateView();

        allReservations.addListener((javafx.collections.ListChangeListener.Change<? extends String> c) -> updateView());
    }

    private void updateView() {
        boolean isEmpty = allReservations.isEmpty();
        emptyPlaceholder.setVisible(isEmpty);
        reservationsListView.setVisible(!isEmpty);
    }


    @FXML
    private void onCancelReservation(ActionEvent event) {
        String selectedItem = reservationsListView.getSelectionModel().getSelectedItem();

        if (selectedItem == null) {
            showCustomAlert("No Selection", "Please select a reservation to cancel.");
            return;
        }

        if (showCustomConfirmation("Cancel Reservation", "Are you sure you want to cancel this reservation?\nThis action cannot be undone.")) {
            try {
                parseAndFreeSeats(selectedItem);
            } catch (Exception e) {
                System.out.println("Error freeing seats: " + e.getMessage());
            }

            allReservations.remove(selectedItem);
            showCustomAlert("Success", "Reservation canceled successfully.");
        }
    }

    private void parseAndFreeSeats(String reservationString) {
        String[] parts = reservationString.split("\\|");
        if (parts.length >= 5) {
            String perfName = parts[1].trim();
            String date = parts[2].trim();
            String seatsPart = parts[4].trim();

            if (seatsPart.startsWith("Seats:")) {
                String seatListStr = seatsPart.substring(6).trim();
                String[] seatArray = seatListStr.split(",");
                List<String> seatsToFree = new ArrayList<>();
                for (String s : seatArray) {
                    seatsToFree.add(s.trim());
                }

                SeatMapController.freeSeats(perfName, date, seatsToFree);
            }
        }
    }

    private void showCustomAlert(String header, String content) {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initStyle(StageStyle.UTILITY);

        VBox root = new VBox(20);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new javafx.geometry.Insets(20));

        root.setStyle("-fx-background-color: " + BG_COLOR + "; -fx-border-color: #d4af37; -fx-border-width: 2;");

        Label hLabel = new Label(header);
        hLabel.setStyle("-fx-text-fill: " + TEXT_COLOR_GOLD + "; -fx-font-size: 20px; -fx-font-weight: bold;");

        Label cLabel = new Label(content);
        cLabel.setStyle("-fx-text-fill: " + TEXT_COLOR_WHITE + "; -fx-font-size: 14px;");

        Button okBtn = new Button("OK");
        okBtn.setStyle("-fx-background-color: " + BTN_COLOR_GOLD + "; -fx-text-fill: #2a0a0a; -fx-font-weight: bold;");
        okBtn.setOnAction(e -> dialog.close());

        root.getChildren().addAll(hLabel, cLabel, okBtn);
        dialog.setScene(new Scene(root, 350, 200));
        dialog.showAndWait();
    }

    private boolean showCustomConfirmation(String header, String content) {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initStyle(StageStyle.UTILITY);

        VBox root = new VBox(20);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new javafx.geometry.Insets(20));

        root.setStyle("-fx-background-color: " + BG_COLOR + "; -fx-border-color: #d4af37; -fx-border-width: 2;");

        Label hLabel = new Label(header);
        hLabel.setStyle("-fx-text-fill: " + TEXT_COLOR_GOLD + "; -fx-font-size: 20px; -fx-font-weight: bold;");

        Label cLabel = new Label(content);
        cLabel.setStyle("-fx-text-fill: " + TEXT_COLOR_WHITE + "; -fx-font-size: 14px;");

        Button yesBtn = new Button("Yes");
        yesBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: #ff6b6b; -fx-font-weight: bold; -fx-border-color: #ff6b6b; -fx-border-radius: 5;");

        Button noBtn = new Button("No");
        noBtn.setStyle("-fx-background-color: " + BTN_COLOR_GOLD + "; -fx-text-fill: #2a0a0a; -fx-font-weight: bold; -fx-background-radius: 5;");

        final boolean[] result = {false};
        yesBtn.setOnAction(e -> { result[0] = true; dialog.close(); });
        noBtn.setOnAction(e -> { result[0] = false; dialog.close(); });

        root.getChildren().addAll(hLabel, cLabel, new HBox(15, yesBtn, noBtn));
        ((HBox)root.getChildren().get(2)).setAlignment(Pos.CENTER);
        dialog.setScene(new Scene(root, 400, 200));
        dialog.showAndWait();
        return result[0];
    }

    @FXML
    private void onMakeReservation(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(AceTheaterApp.class.getResource("reservation-choice.fxml"));
        Parent root = loader.load();

        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.setTitle("Ace Theater - Reserve Seats");
        currentStage.getScene().setRoot(root);
    }

    @FXML
    private void onMenuClick(javafx.scene.input.MouseEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(AceTheaterApp.class.getResource("main-menu.fxml"));
        Parent root = loader.load();

        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.setTitle("Ace Theater");
        currentStage.getScene().setRoot(root);
    }
}
