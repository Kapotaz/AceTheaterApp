package com.example.acetheaterproject;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Popup;
import javafx.stage.Stage;
import javafx.animation.ScaleTransition;
import javafx.util.Duration;
import javafx.scene.layout.VBox;
import javafx.scene.Parent;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReservationChoiceController {

    @FXML private HBox imagePanel;

    private static final Map<String, String> performanceDetails = new HashMap<>();
    static {
        performanceDetails.put("Starlight Odyssey", "A cosmic adventure musical where a group of dreamers travel through space searching for the legendary 'Starlight', discovering friendship and courage along the way.");
        performanceDetails.put("Echoes of Olympus", "An ancient Greek-inspired musical blending mythology, powerful ballads, and stunning choreography as gods and mortals struggle to shape their destinies.");
        performanceDetails.put("Comedy Under the Lights", "A live stand-up comedy night featuring local comedians, quick-witted improv, and hilarious audience participation under the glowing marquee lights.");
        performanceDetails.put("Dance through the Decades", "A vibrant live dance performance showcasing music and styles from the 1920s to today, inviting spectators to experience the rhythm of history.");
        performanceDetails.put("Neon City Nights", "An action-packed drama about a group of vigilantes battling crime in a futuristic metropolis illuminated by neon glow.");
        performanceDetails.put("The Whispering Forest", "A suspenseful fantasy film where a young heroine braves mystical woods filled with secrets, magic, and creatures of the night to uncover a hidden truth.");
    }

    @FXML
    private void initialize() {
        showMusicals();
    }

    @FXML
    private void onMusicals() {
        showMusicals();
    }

    @FXML
    private void onLive() {
        showLivePerformances();
    }

    @FXML
    private void onMovies() {
        showMovies();
    }

    private void showMusicals() {
        imagePanel.getChildren().clear();
        imagePanel.getChildren().addAll(
                createPosterWithInfo("musical1.jpg", "Starlight Odyssey"),
                createPosterWithInfo("musical2.jpg", "Echoes of Olympus")
        );
    }

    private void showLivePerformances() {
        imagePanel.getChildren().clear();
        imagePanel.getChildren().addAll(
                createPosterWithInfo("live1.jpg", "Comedy Under the Lights"),
                createPosterWithInfo("live2.jpg", "Dance through the Decades")
        );
    }

    private void showMovies() {
        imagePanel.getChildren().clear();
        imagePanel.getChildren().addAll(
                createPosterWithInfo("movie1.jpg", "Neon City Nights"),
                createPosterWithInfo("movie2.jpg", "The Whispering Forest")
        );
    }

    private VBox createPosterWithInfo(String fileName, String performanceName) {
        ImageView imageView = new ImageView();
        imageView.setFitHeight(280);
        imageView.setFitWidth(400);
        imageView.setPreserveRatio(true);
        imageView.setCursor(javafx.scene.Cursor.HAND);

        try {
            if (AceTheaterApp.class.getResource(fileName) != null) {
                Image img = new Image(AceTheaterApp.class.getResource(fileName).toExternalForm());
                imageView.setImage(img);
            }
        } catch (Exception e) {
            System.out.println("Could not load image: " + fileName);
        }

        ScaleTransition scaleIn = new ScaleTransition(Duration.millis(200), imageView);
        scaleIn.setToX(1.1);
        scaleIn.setToY(1.1);

        ScaleTransition scaleOut = new ScaleTransition(Duration.millis(200), imageView);
        scaleOut.setToX(1.0);
        scaleOut.setToY(1.0);

        imageView.setOnMouseEntered(e -> {
            scaleOut.stop();
            scaleIn.playFromStart();
        });

        imageView.setOnMouseExited(e -> {
            scaleIn.stop();
            scaleOut.playFromStart();
        });

        imageView.setOnMouseClicked(event -> {
            try {
                showDateSelectionWindow(performanceName, (Node)event.getSource());
            } catch (IOException e) {
                e.printStackTrace();
            }
        });


        Label infoLabel = new Label("Info"); // Αλλαγή κειμένου

        infoLabel.setStyle("-fx-text-fill: #FFD700; " +
                "-fx-font-size: 20px; " +
                "-fx-cursor: hand; " +
                "-fx-font-weight: bold; " +
                "-fx-font-style: italic;"); // Πλάγια γραφή

        Popup infoPopup = createInfoPopup(performanceName);

        infoLabel.setOnMouseEntered(event -> {
            Node source = (Node) event.getSource();
            infoPopup.show(source, event.getScreenX(), event.getScreenY() + 20);
        });

        infoLabel.setOnMouseExited(event -> {
            infoPopup.hide();
        });

        VBox container = new VBox(10);
        container.setAlignment(Pos.CENTER);
        container.getChildren().addAll(imageView, infoLabel); // Χρήση του infoLabel

        return container;
    }


    private Popup createInfoPopup(String performanceName) {
        Popup popup = new Popup();

        VBox content = new VBox(10);
        content.setPadding(new Insets(15));
        content.setStyle("-fx-background-color: #234968; -fx-border-color: #f5f5f5; -fx-border-width: 2; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.6), 10, 0, 0, 0);");
        content.setMaxWidth(300);

        Label titleLabel = new Label(performanceName);
        titleLabel.setStyle("-fx-text-fill: #f5f5f5; -fx-font-size: 18px; -fx-font-family: 'Serif'; -fx-font-weight: bold;");

        String detailsText = performanceDetails.getOrDefault(performanceName, "No details available.");
        Label detailsLabel = new Label(detailsText);
        detailsLabel.setStyle("-fx-text-fill: #d0e4ff; -fx-font-size: 14px;");
        detailsLabel.setWrapText(true);

        content.getChildren().addAll(titleLabel, detailsLabel);
        popup.getContent().add(content);

        return popup;
    }

    private void showDateSelectionWindow(String performanceName, Node ownerNode) throws IOException {
        Stage ownerStage = (Stage) ownerNode.getScene().getWindow();
        Stage dialogStage = new Stage();
        dialogStage.initOwner(ownerStage);
        dialogStage.initModality(Modality.APPLICATION_MODAL);
        dialogStage.setTitle("Ace Theater - Select Date");

        BorderPane root = new BorderPane();
        root.setPrefSize(600, 400);
        root.setStyle("-fx-background-color: #2a0a0a; -fx-border-color: #d4af37; -fx-border-width: 2;");

        VBox topBox = new VBox(5);
        topBox.setAlignment(Pos.CENTER);
        topBox.setPadding(new Insets(20, 20, 10, 20));

        Label title = new Label("ACE THEATER");
        title.setStyle("-fx-text-fill: #FFD700; -fx-font-size: 28px; -fx-font-family: 'Serif'; -fx-font-weight: bold;");

        Label subtitle = new Label("Select date for: " + performanceName);
        subtitle.setStyle("-fx-text-fill: #fdf5e6; -fx-font-size: 18px; -fx-font-weight: bold;");

        topBox.getChildren().addAll(title, subtitle);
        root.setTop(topBox);

        VBox centerBox = new VBox(12);
        centerBox.setAlignment(Pos.CENTER);
        centerBox.setPadding(new Insets(10, 40, 10, 40));

        Label hint = new Label("Choose one of the available dates:");
        hint.setStyle("-fx-text-fill: #fdf5e6; -fx-font-size: 14px;");
        centerBox.getChildren().add(hint);

        List<String> availableDates = Arrays.asList(
                "25 Nov 2025 - 21:00",
                "26 Nov 2025 - 21:00",
                "28 Nov 2025 - 19:00"
        );

        String normalStyle = "-fx-background-color: transparent; " +
                "-fx-border-color: #FFD700; " +
                "-fx-border-width: 2px; " +
                "-fx-border-radius: 5; " +
                "-fx-text-fill: #FFD700; " +
                "-fx-font-size: 16px; " +
                "-fx-font-family: 'Serif'; " +
                "-fx-cursor: hand; " +
                "-fx-padding: 6 14 6 14;";

        String hoverStyle = "-fx-background-color: #FFD700; " +
                "-fx-border-color: #FFD700; " +
                "-fx-border-width: 2px; " +
                "-fx-border-radius: 5; " +
                "-fx-text-fill: #2b0505; " +
                "-fx-font-size: 16px; " +
                "-fx-font-family: 'Serif'; " +
                "-fx-cursor: hand; " +
                "-fx-padding: 6 14 6 14;";

        for (String date : availableDates) {
            Button dateButton = new Button(date);
            dateButton.setPrefWidth(260);

            dateButton.setStyle(normalStyle);

            dateButton.setOnMouseEntered(e -> dateButton.setStyle(hoverStyle));
            dateButton.setOnMouseExited(e -> dateButton.setStyle(normalStyle));

            dateButton.setOnAction(event -> {
                dialogStage.close();
                try {
                    navigateToSeatMap(performanceName, date, ownerNode);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
            centerBox.getChildren().add(dateButton);
        }

        root.setCenter(centerBox);

        HBox bottomBox = new HBox();
        bottomBox.setAlignment(Pos.CENTER_RIGHT);
        bottomBox.setPadding(new Insets(10, 20, 20, 20));

        Button cancelButton = new Button("Cancel");
        cancelButton.setStyle("-fx-background-color: #8b0000; -fx-text-fill: white; -fx-font-weight: bold;");
        cancelButton.setOnAction(e -> dialogStage.close());

        bottomBox.getChildren().add(cancelButton);
        root.setBottom(bottomBox);

        Scene scene = new Scene(root);
        dialogStage.setScene(scene);
        dialogStage.setWidth(620);
        dialogStage.setHeight(420);
        dialogStage.showAndWait();
    }

    private void navigateToSeatMap(String performanceName, String date, Node sourceNode) throws IOException {
        FXMLLoader loader = new FXMLLoader(AceTheaterApp.class.getResource("seat-map.fxml"));
        Parent root = loader.load();

        SeatMapController controller = loader.getController();
        controller.initData(performanceName, date);

        Stage currentStage = (Stage) sourceNode.getScene().getWindow();
        currentStage.setTitle("Ace Theater - Select Seats");
        currentStage.getScene().setRoot(root);
    }

    @FXML
    private void onMenuClick(javafx.scene.input.MouseEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(AceTheaterApp.class.getResource("main-menu.fxml"));
        Parent root = loader.load();

        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.setTitle("Ace Theater");
        currentStage.getScene().setRoot(root);
    }
}
