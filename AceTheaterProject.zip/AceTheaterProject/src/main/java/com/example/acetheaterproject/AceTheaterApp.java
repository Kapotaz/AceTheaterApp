package com.example.acetheaterproject;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;

public class AceTheaterApp extends Application {

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(AceTheaterApp.class.getResource("main-menu.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1280, 720);
        stage.setTitle("Ace Theater");
        stage.setScene(scene);

        stage.setOnCloseRequest(event -> {
            event.consume();
            showCustomExitDialog(stage);
        });

        stage.show();
    }

    private void showCustomExitDialog(Stage ownerStage) {
        Stage dialog = new Stage();
        dialog.initOwner(ownerStage);
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initStyle(StageStyle.UTILITY);
        dialog.setTitle("Exit Confirmation");

        VBox root = new VBox(20);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: #1a0f0a; -fx-border-color: #d4af37; -fx-border-width: 2;");

        Label headerLabel = new Label("Exit Application");
        headerLabel.setStyle("-fx-text-fill: #FFD700; -fx-font-size: 20px; -fx-font-weight: bold;");

        Label contentLabel = new Label("Are you sure you want to exit Ace Theater?");
        contentLabel.setStyle("-fx-text-fill: #fdf5e6; -fx-font-size: 14px;");

        Button yesBtn = new Button("Yes, Exit");
        yesBtn.setStyle("-fx-background-color: #8b0000; -fx-text-fill: white; -fx-font-weight: bold; -fx-cursor: hand;");

        Button noBtn = new Button("No, Stay");
        noBtn.setStyle("-fx-background-color: #d4af37; -fx-text-fill: #1a0f0a; -fx-font-weight: bold; -fx-cursor: hand;");

        yesBtn.setOnAction(e -> {
            dialog.close();
            Platform.exit();
            System.exit(0);
        });

        noBtn.setOnAction(e -> dialog.close());

        HBox buttonsBox = new HBox(20, yesBtn, noBtn);
        buttonsBox.setAlignment(Pos.CENTER);

        root.getChildren().addAll(headerLabel, contentLabel, buttonsBox);

        Scene scene = new Scene(root, 400, 200);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    public static void main(String[] args) {
        launch();
    }
}
