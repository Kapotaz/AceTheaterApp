package com.example.acetheaterproject;

public class Launcher {
    public static void main(String[] args) {
        AceTheaterApp.main(args);
    }
}
