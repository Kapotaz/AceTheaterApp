package com.example.acetheaterproject;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;

public class MainMenuController {

    @FXML private Label reservationBadge;
    @FXML private Button btnTheater;
    @FXML private Button btnPlaying;
    @FXML private Button btnReserve;
    @FXML private Button btnMyRes;
    @FXML private Button btnAbout;
    @FXML private Button btnExit;

    @FXML
    private void initialize() {
        updateBadge();

        MyReservationsController.allReservations.addListener((javafx.collections.ListChangeListener.Change<? extends String> c) -> {
            updateBadge();
        });

        if (reservationBadge != null) {
            reservationBadge.setTranslateX(-15); // Αριστερά
            reservationBadge.setTranslateY(10);  // Κάτω
        }

    }

    private void updateBadge() {
        if (reservationBadge == null) return; //Ασφαλεια

        int reservationCount = MyReservationsController.allReservations.size();

        if (reservationCount > 0) {
            reservationBadge.setText(String.valueOf(reservationCount));
            reservationBadge.setVisible(true);
        } else {
            reservationBadge.setVisible(false);
        }
    }

    @FXML private void onTheater(ActionEvent event) { navigate(event, "the-theater.fxml", "Ace Theater - The Theater"); }
    @FXML private void onPerformances(ActionEvent event) { navigate(event, "performances.fxml", "Ace Theater - Playing Now"); }
    @FXML private void onReservation(ActionEvent event) { navigate(event, "reservation-choice.fxml", "Ace Theater - Reserve Seats"); }
    @FXML private void onMyReservations(ActionEvent event) { navigate(event, "my-reservations.fxml", "Ace Theater - My Reservations"); }
    @FXML private void onAbout(ActionEvent event) { navigate(event, "about-us.fxml", "Ace Theater - About Us"); }
    @FXML private void onExit(ActionEvent event) {
        if (showCustomConfirmation("Exit Application", "Are you sure you want to exit Ace Theater?")) {
            System.exit(0);
        }
    }

    private void navigate(ActionEvent event, String fxmlFile, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(AceTheaterApp.class.getResource(fxmlFile));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.getScene().setRoot(root);
            stage.setTitle(title);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private boolean showCustomConfirmation(String header, String content) {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initStyle(StageStyle.UTILITY);

        VBox root = new VBox(20);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new javafx.geometry.Insets(20));
        root.setStyle("-fx-background-color: #1a0f0a; -fx-border-color: #d4af37; -fx-border-width: 2;");

        Label hLabel = new Label(header);
        hLabel.setStyle("-fx-text-fill: #FFD700; -fx-font-size: 20px; -fx-font-weight: bold;");

        Label cLabel = new Label(content);
        cLabel.setStyle("-fx-text-fill: #fdf5e6; -fx-font-size: 14px;");

        Button yesBtn = new Button("Yes, Exit");
        yesBtn.setStyle("-fx-background-color: #8b0000; -fx-text-fill: white; -fx-font-weight: bold;");

        Button noBtn = new Button("No, Stay");
        noBtn.setStyle("-fx-background-color: #d4af37; -fx-text-fill: #1a0f0a; -fx-font-weight: bold;");

        final boolean[] result = {false};
        yesBtn.setOnAction(e -> { result[0] = true; dialog.close(); });
        noBtn.setOnAction(e -> { result[0] = false; dialog.close(); });

        HBox buttonBox = new HBox(15, yesBtn, noBtn);
        buttonBox.setAlignment(Pos.CENTER);

        root.getChildren().addAll(hLabel, cLabel, buttonBox);

        dialog.setScene(new Scene(root, 400, 200));
        dialog.showAndWait();
        return result[0];
    }
}
