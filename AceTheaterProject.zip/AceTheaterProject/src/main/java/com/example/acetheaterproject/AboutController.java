package com.example.acetheaterproject;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Parent;
import java.io.IOException;

public class AboutController {

    @FXML
    private void onMenuClick(javafx.scene.input.MouseEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(AceTheaterApp.class.getResource("main-menu.fxml"));
        Parent root = loader.load();

        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.setTitle("Ace Theater");
        currentStage.getScene().setRoot(root);
    }
}
