package com.example.acetheaterproject;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.Parent;
import java.io.IOException;
import java.net.URL;
import java.util.Arrays;
import java.util.List;

public class PerformancesController {

    @FXML private ImageView imgStarlight;
    @FXML private ImageView imgEchoes;
    @FXML private ImageView imgComedy;
    @FXML private ImageView imgDance;
    @FXML private ImageView imgNeon;
    @FXML private ImageView imgForest;

    @FXML
    private void initialize() {

        loadImage(imgStarlight, "/com/example/acetheaterproject/musical1.jpg");
        loadImage(imgEchoes,    "/com/example/acetheaterproject/musical2.jpg");
        loadImage(imgComedy,    "/com/example/acetheaterproject/live1.jpg");
        loadImage(imgDance,     "/com/example/acetheaterproject/live2.jpg");
        loadImage(imgNeon,      "/com/example/acetheaterproject/movie1.jpg");
        loadImage(imgForest,    "/com/example/acetheaterproject/movie2.jpg");
    }

    private void loadImage(ImageView view, String absolutePath) {
        try {
            URL url = AceTheaterApp.class.getResource(absolutePath);
            if (url == null) {
                System.out.println("Resource NOT found on classpath: " + absolutePath);
                return;
            }
            Image image = new Image(url.toExternalForm());
            view.setImage(image);
        } catch (Exception e) {
            System.out.println("Error loading image: " + absolutePath + " -> " + e.getMessage());
        }
    }


    @FXML
    private void onStarlightClick(javafx.scene.input.MouseEvent event) throws IOException {
        showDateSelectionWindow("Starlight Odyssey", (Node) event.getSource());
    }

    @FXML
    private void onEchoesClick(javafx.scene.input.MouseEvent event) throws IOException {
        showDateSelectionWindow("Echoes of Olympus", (Node) event.getSource());
    }

    @FXML
    private void onComedyClick(javafx.scene.input.MouseEvent event) throws IOException {
        showDateSelectionWindow("Comedy Under the Lights", (Node) event.getSource());
    }

    @FXML
    private void onDanceClick(javafx.scene.input.MouseEvent event) throws IOException {
        showDateSelectionWindow("Dance through the Decades", (Node) event.getSource());
    }

    @FXML
    private void onNeonClick(javafx.scene.input.MouseEvent event) throws IOException {
        showDateSelectionWindow("Neon City Nights", (Node) event.getSource());
    }

    @FXML
    private void onForestClick(javafx.scene.input.MouseEvent event) throws IOException {
        showDateSelectionWindow("The Whispering Forest", (Node) event.getSource());
    }


    private void showDateSelectionWindow(String performanceName, Node ownerNode) throws IOException {
        Stage ownerStage = (Stage) ownerNode.getScene().getWindow();
        Stage dialogStage = new Stage();
        dialogStage.initOwner(ownerStage);
        dialogStage.initModality(Modality.APPLICATION_MODAL);
        dialogStage.setTitle("Ace Theater - Select Date");

        BorderPane root = new BorderPane();
        root.setPrefSize(600, 400);
        root.setStyle("-fx-background-color: #2a0a0a; -fx-border-color: #d4af37; -fx-border-width: 2;");

        VBox topBox = new VBox(5);
        topBox.setAlignment(Pos.CENTER);
        topBox.setPadding(new Insets(20, 20, 10, 20));

        Label title = new Label("ACE THEATER");
        title.setStyle("-fx-text-fill: #FFD700; -fx-font-size: 28px; -fx-font-family: 'Serif'; -fx-font-weight: bold;");

        Label subtitle = new Label("Select date for: " + performanceName);
        subtitle.setStyle("-fx-text-fill: #fdf5e6; -fx-font-size: 18px; -fx-font-weight: bold;");

        topBox.getChildren().addAll(title, subtitle);
        root.setTop(topBox);

        VBox centerBox = new VBox(12);
        centerBox.setAlignment(Pos.CENTER);
        centerBox.setPadding(new Insets(10, 40, 10, 40));

        Label hint = new Label("Choose one of the available dates:");
        hint.setStyle("-fx-text-fill: #fdf5e6; -fx-font-size: 14px;");
        centerBox.getChildren().add(hint);

        List<String> availableDates = Arrays.asList(
                "25 Nov 2025 - 21:00",
                "26 Nov 2025 - 21:00",
                "28 Nov 2025 - 19:00"
        );

        // --- ΣΤΥΛ ΓΙΑ ΤΑ GHOST BUTTONS ---
        String normalStyle = "-fx-background-color: transparent; " +
                "-fx-border-color: #FFD700; " +
                "-fx-border-width: 2px; " +
                "-fx-border-radius: 5; " +
                "-fx-text-fill: #FFD700; " +
                "-fx-font-size: 16px; " +
                "-fx-font-family: 'Serif'; " +
                "-fx-cursor: hand; " +
                "-fx-padding: 6 14 6 14;";

        String hoverStyle = "-fx-background-color: #FFD700; " +
                "-fx-border-color: #FFD700; " +
                "-fx-border-width: 2px; " +
                "-fx-border-radius: 5; " +
                "-fx-text-fill: #2b0505; " +
                "-fx-font-size: 16px; " +
                "-fx-font-family: 'Serif'; " +
                "-fx-cursor: hand; " +
                "-fx-padding: 6 14 6 14;";

        for (String date : availableDates) {
            Button dateButton = new Button(date);
            dateButton.setPrefWidth(260);

            dateButton.setStyle(normalStyle);

            dateButton.setOnMouseEntered(e -> dateButton.setStyle(hoverStyle));
            dateButton.setOnMouseExited(e -> dateButton.setStyle(normalStyle));

            dateButton.setOnAction(event -> {
                dialogStage.close();
                try {
                    navigateToSeatMap(performanceName, date, ownerNode);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
            centerBox.getChildren().add(dateButton);
        }

        root.setCenter(centerBox);

        HBox bottomBox = new HBox();
        bottomBox.setAlignment(Pos.CENTER_RIGHT);
        bottomBox.setPadding(new Insets(10, 20, 20, 20));

        Button cancelButton = new Button("Cancel");
        cancelButton.setStyle("-fx-background-color: #8b0000; -fx-text-fill: white; -fx-font-weight: bold;");
        cancelButton.setOnAction(e -> dialogStage.close());

        bottomBox.getChildren().add(cancelButton);
        root.setBottom(bottomBox);

        Scene scene = new Scene(root);
        dialogStage.setScene(scene);
        dialogStage.setWidth(620);
        dialogStage.setHeight(420);
        dialogStage.showAndWait();
    }


    private void navigateToSeatMap(String performanceName, String date, Node sourceNode) throws IOException {
        FXMLLoader loader = new FXMLLoader(AceTheaterApp.class.getResource("seat-map.fxml"));
        Parent root = loader.load();

        SeatMapController controller = loader.getController();
        controller.initData(performanceName, date);

        Stage currentStage = (Stage) sourceNode.getScene().getWindow();
        currentStage.setTitle("Ace Theater - Select Seats");
        currentStage.getScene().setRoot(root);
    }

    @FXML
    private void onMenuClick(javafx.scene.input.MouseEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(AceTheaterApp.class.getResource("main-menu.fxml"));
        Parent root = loader.load();

        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.setTitle("Ace Theater");
        currentStage.getScene().setRoot(root);
    }
}
