package com.example.acetheaterproject;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.scene.Parent;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class SeatMapController {

    private static final String STYLE_AVAILABLE_ECONOMY = "-fx-background-color: #4CAF50; -fx-text-fill: black;";
    private static final String STYLE_AVAILABLE_VIP = "-fx-background-color: #FFA726; -fx-text-fill: black;";
    private static final String STYLE_SELECTED = "-fx-background-color: #03A9F4; -fx-text-fill: white; -fx-border-color: white; -fx-border-width: 2;";
    private static final String STYLE_BOOKED = "-fx-background-color: #D32F2F; -fx-text-fill: white;";

    private static final Map<String, Set<String>> bookedSeatsMap = new HashMap<>();
    private static int reservationCounter = 1000;

    @FXML private Label performanceInfoLabel;
    @FXML private GridPane seatGrid;
    @FXML private Label totalPriceLabel;

    private String performanceName;
    private String performanceDate;
    private double currentTotal = 0.0;

    public static void freeSeats(String perfName, String perfDate, List<String> seatsToFree) {
        String key = perfName + "-" + perfDate;
        if (bookedSeatsMap.containsKey(key)) {
            bookedSeatsMap.get(key).removeAll(seatsToFree);
        }
    }

    private static class SeatState {
        String originalStyle;
        double price;
        String seatNumber;

        SeatState(String originalStyle, double price, String seatNumber) {
            this.originalStyle = originalStyle;
            this.price = price;
            this.seatNumber = seatNumber;
        }
    }

    public void initData(String performanceName, String date) {
        this.performanceName = performanceName;
        this.performanceDate = date;
        if (performanceInfoLabel != null) {
            performanceInfoLabel.setText(performanceName + "\n" + date);
        }
        populateSeatMap();
        updateTotalLabel();
    }

    private String getPerformanceKey() {
        return performanceName + "-" + performanceDate;
    }

    private Set<String> getBookedSeats() {
        return bookedSeatsMap.computeIfAbsent(getPerformanceKey(), k -> new HashSet<>());
    }

    private void populateSeatMap() {
        if (seatGrid == null) return;
        seatGrid.getChildren().clear();
        currentTotal = 0.0;

        double vipPrice, economyPrice;
        if (performanceName != null && (performanceName.toLowerCase().contains("odyssey") || performanceName.toLowerCase().contains("olympus"))) {
            vipPrice = 60.0; economyPrice = 30.0;
        } else if (performanceName != null && (performanceName.toLowerCase().contains("comedy") || performanceName.toLowerCase().contains("dance"))) {
            vipPrice = 45.0; economyPrice = 25.0;
        } else {
            vipPrice = 20.0; economyPrice = 10.0;
        }

        int numRows = 6;
        int numCols = 15;
        Set<String> bookedSeats = getBookedSeats();

        for (int row = 0; row < numRows; row++) {
            for (int col = 0; col < numCols; col++) {
                String seatNumber = (char)('A' + row) + "" + (col + 1);
                Button seatButton = new Button();
                seatButton.setPrefSize(60, 45);
                seatButton.setAlignment(Pos.CENTER);

                String initialStyle;
                double price;

                if (row < 4) {
                    price = economyPrice;
                    initialStyle = STYLE_AVAILABLE_ECONOMY;
                } else {
                    price = vipPrice;
                    initialStyle = STYLE_AVAILABLE_VIP;
                }

                seatButton.setText(String.format("%s\n€%.0f", seatNumber, price));
                SeatState state = new SeatState(initialStyle, price, seatNumber);

                if (bookedSeats.contains(seatNumber)) {
                    seatButton.setStyle(STYLE_BOOKED);
                    state.originalStyle = STYLE_BOOKED;
                    seatButton.setDisable(true);
                } else {
                    seatButton.setStyle(initialStyle);
                }

                seatButton.setUserData(state);
                seatButton.setOnAction(e -> handleSeatClick(seatButton));
                seatGrid.add(seatButton, col, row);
            }
        }
    }

    private void handleSeatClick(Button seatButton) {
        SeatState state = (SeatState) seatButton.getUserData();
        String style = seatButton.getStyle();

        if (STYLE_BOOKED.equals(style)) return;

        if (STYLE_SELECTED.equals(style)) {
            seatButton.setStyle(state.originalStyle);
            currentTotal -= state.price;
        } else {
            seatButton.setStyle(STYLE_SELECTED);
            currentTotal += state.price;
        }
        updateTotalLabel();
    }

    private void updateTotalLabel() {
        if (totalPriceLabel != null) {
            totalPriceLabel.setText(String.format("Total: €%.2f", currentTotal));
        }
    }

    @FXML
    private void onClearSelections(ActionEvent event) {
        for (Node node : seatGrid.getChildren()) {
            if (node instanceof Button) {
                Button btn = (Button) node;
                String style = btn.getStyle();
                if (STYLE_SELECTED.equals(style)) {
                    SeatState state = (SeatState) btn.getUserData();
                    btn.setStyle(state.originalStyle);
                }
            }
        }
        currentTotal = 0.0;
        updateTotalLabel();
    }

    @FXML
    private void onConfirm(ActionEvent event) {
        List<SeatState> selectedSeats = new ArrayList<>();
        for (Node node : seatGrid.getChildren()) {
            if (node instanceof Button) {
                Button btn = (Button) node;
                if (STYLE_SELECTED.equals(btn.getStyle())) {
                    selectedSeats.add((SeatState) btn.getUserData());
                }
            }
        }

        if (selectedSeats.isEmpty()) {
            showCustomAlert("No Selection", "Please select at least one seat.");
            return;
        }

        showCustomerForm(selectedSeats, (Node) event.getSource());
    }

    private void showCustomerForm(List<SeatState> selectedSeats, Node ownerNode) {
        Stage ownerStage = (Stage) ownerNode.getScene().getWindow();
        Stage dialog = new Stage();
        dialog.initOwner(ownerStage);
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("Ace Theater - Customer Details");

        VBox root = new VBox(12);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: #2a0a0a; -fx-border-color: #d4af37; -fx-border-width: 2;");

        Label title = new Label("Reservation Details");
        title.setStyle("-fx-text-fill: #FFD700; -fx-font-size: 24px; -fx-font-family: 'Serif'; -fx-font-weight: bold;");

        TextField firstNameField = new TextField(); firstNameField.setPromptText("First Name");
        TextField lastNameField = new TextField(); lastNameField.setPromptText("Last Name");
        TextField phoneField = new TextField(); phoneField.setPromptText("Mobile");
        TextField emailField = new TextField(); emailField.setPromptText("Email");

        addLetterOnlyFilter(firstNameField);
        addLetterOnlyFilter(lastNameField);
        addNumericOnlyFilter(phoneField);

        styleTextField(firstNameField);
        styleTextField(lastNameField);
        styleTextField(phoneField);
        styleTextField(emailField);

        VBox fieldsBox = new VBox(8, firstNameField, lastNameField, phoneField, emailField);

        Label paymentLabel = new Label("Payment method:");
        paymentLabel.setStyle("-fx-text-fill: #fdf5e6; -fx-font-size: 16px;");

        ToggleGroup paymentGroup = new ToggleGroup();
        RadioButton rbDesk = new RadioButton("Pay at theater desk");
        RadioButton rbCard = new RadioButton("Pay by card");
        rbDesk.setToggleGroup(paymentGroup);
        rbCard.setToggleGroup(paymentGroup);
        rbDesk.setSelected(true);
        styleRadio(rbDesk);
        styleRadio(rbCard);

        VBox paymentBox = new VBox(5, paymentLabel, rbDesk, rbCard);

        TextField cardHolderField = new TextField(); cardHolderField.setPromptText("Card Holder Name");
        addLetterOnlyFilter(cardHolderField);
        TextField cardNumberField = new TextField(); cardNumberField.setPromptText("Card Number");
        addNumericOnlyFilter(cardNumberField);

        ComboBox<String> cardExpiryCombo = new ComboBox<>();
        cardExpiryCombo.setPromptText("Expiry (MM/YY)");
        cardExpiryCombo.getItems().addAll("01/26", "02/26", "03/26", "04/26", "05/26", "06/26", "07/26", "08/26", "09/26", "10/26", "11/26", "12/26");
        cardExpiryCombo.setStyle("-fx-background-color: #f5f5f5;");

        TextField cardCvvField = new TextField(); cardCvvField.setPromptText("CVV");
        addNumericOnlyFilter(cardCvvField);

        styleTextField(cardHolderField);
        styleTextField(cardNumberField);
        styleTextField(cardCvvField);

        VBox cardBox = new VBox(5, cardHolderField, cardNumberField, cardExpiryCombo, cardCvvField);
        cardBox.setVisible(false);
        cardBox.managedProperty().bind(cardBox.visibleProperty());

        rbCard.selectedProperty().addListener((obs, was, isNow) -> cardBox.setVisible(isNow));

        HBox buttonsBox = new HBox(15);
        buttonsBox.setAlignment(Pos.CENTER_RIGHT);

        Button cancelBtn = new Button("Cancel");
        cancelBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: #fdf5e6; -fx-border-color: #fdf5e6; -fx-cursor: hand;");
        cancelBtn.setOnAction(e -> dialog.close());

        Button completeBtn = new Button("Complete & Generate QR");
        completeBtn.setStyle("-fx-background-color: linear-gradient(to bottom, #e6c269, #b88a32); -fx-text-fill: #2a0a0a; -fx-font-weight: bold; -fx-font-size: 16px; -fx-cursor: hand;");
        completeBtn.setOnAction(e -> {
            if (!validateCustomerForm(firstNameField, lastNameField, phoneField, emailField, rbCard.isSelected(), cardHolderField, cardNumberField, cardExpiryCombo, cardCvvField)) {
                return;
            }
            confirmBooking(dialog, selectedSeats, firstNameField, lastNameField, phoneField, emailField, rbDesk.isSelected(), ownerStage);
        });

        buttonsBox.getChildren().addAll(cancelBtn, completeBtn);
        root.getChildren().addAll(title, fieldsBox, paymentBox, cardBox, buttonsBox);

        Scene scene = new Scene(root, 450, 580);
        dialog.setScene(scene);
        dialog.setWidth(460);
        dialog.setHeight(600);
        dialog.showAndWait();
    }

    private void styleTextField(TextField tf) {
        tf.setStyle("-fx-background-color: #f5f5f5;");
    }

    private void styleRadio(RadioButton rb) {
        rb.setStyle("-fx-text-fill: #f5f5f5;");
    }

    private void addLetterOnlyFilter(TextField field) {
        field.textProperty().addListener((obs, oldVal, newVal) -> {
            if (!newVal.matches("[a-zA-Zα-ωΑ-Ω ]*")) field.setText(oldVal);
        });
    }

    private void addNumericOnlyFilter(TextField field) {
        field.textProperty().addListener((obs, oldVal, newVal) -> {
            if (!newVal.matches("\\d*")) field.setText(oldVal);
        });
    }

    private boolean validateCustomerForm(TextField first, TextField last, TextField phone, TextField email, boolean cardSelected, TextField cardHolder, TextField cardNum, ComboBox<String> expiry, TextField cvv) {
        if (first.getText().isEmpty() || last.getText().isEmpty() || phone.getText().isEmpty() || email.getText().isEmpty()) {
            showCustomAlert("Missing Information", "Please fill in all personal details.");
            return false;
        }
        if (!email.getText().contains("@")) {
            showCustomAlert("Invalid Email", "Email address must contain '@'.");
            return false;
        }
        if (cardSelected) {
            if (cardHolder.getText().isEmpty() || cardNum.getText().isEmpty() || expiry.getValue() == null || cvv.getText().isEmpty()) {
                showCustomAlert("Card Information", "Please fill in all card details.");
                return false;
            }
        }
        return true;
    }

    private void confirmBooking(Stage dialog, List<SeatState> selectedSeats, TextField first, TextField last, TextField phone, TextField email, boolean isDesk, Stage ownerStage) {
        Set<String> bookedSeats = getBookedSeats();
        List<String> bookedSeatNumbers = new ArrayList<>();

        for (Node node : seatGrid.getChildren()) {
            if (node instanceof Button) {
                Button btn = (Button) node;
                if (STYLE_SELECTED.equals(btn.getStyle())) {
                    SeatState st = (SeatState) btn.getUserData();
                    bookedSeats.add(st.seatNumber);
                    bookedSeatNumbers.add(st.seatNumber);
                    btn.setStyle(STYLE_BOOKED);
                    st.originalStyle = STYLE_BOOKED;
                    btn.setDisable(true);
                }
            }
        }

        double total = selectedSeats.stream().mapToDouble(s -> s.price).sum();
        currentTotal = 0.0;
        updateTotalLabel();

        int reservationId = reservationCounter++;
        String qrData = buildQrData(reservationId, first.getText(), last.getText(), phone.getText(), email.getText(), isDesk ? "Desk" : "Card", selectedSeats, total);

        String reservationSummary = String.format("ID #%d | %s | %s | %s | Seats: %s",
                reservationId, performanceName, performanceDate, first.getText()+" "+last.getText(), String.join(", ", bookedSeatNumbers));

        MyReservationsController.allReservations.add(reservationSummary);

        dialog.close();
        showQrWindow(qrData, reservationId, first.getText() + " " + last.getText(), bookedSeatNumbers, total, isDesk ? "Pay at Desk" : "Card", email.getText(), phone.getText(), reservationSummary, ownerStage);
    }

    private String buildQrData(int reservationId, String firstName, String lastName, String phone, String email, String paymentMethod, List<SeatState> seats, double total) {
        StringBuilder sb = new StringBuilder();
        sb.append("ACE THEATER\nID: ").append(reservationId).append("\nName: ").append(firstName).append(" ").append(lastName).append("\nTotal: ").append(total);
        return sb.toString();
    }

    private void showCustomAlert(String header, String content) {
        Stage alertStage = new Stage();
        alertStage.initModality(Modality.APPLICATION_MODAL);
        alertStage.initStyle(StageStyle.UTILITY);
        alertStage.setTitle("Ace Theater - Alert");

        VBox root = new VBox(20);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: #2a0a0a; -fx-border-color: #d4af37; -fx-border-width: 2;");

        Label headerLabel = new Label(header);
        headerLabel.setStyle("-fx-text-fill: #f5f5f5; -fx-font-size: 20px; -fx-font-weight: bold;");

        Label contentLabel = new Label(content);
        contentLabel.setStyle("-fx-text-fill: #d0e4ff; -fx-font-size: 14px;");
        contentLabel.setWrapText(true);

        Button okButton = new Button("OK");
        okButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 5 20;");
        okButton.setOnAction(e -> alertStage.close());

        root.getChildren().addAll(headerLabel, contentLabel, okButton);

        Scene scene = new Scene(root, 350, 200);
        alertStage.setScene(scene);
        alertStage.setWidth(360);
        alertStage.setHeight(220);
        alertStage.showAndWait();
    }

    private boolean showCancelConfirmation() {
        Stage confirmStage = new Stage();
        confirmStage.initModality(Modality.APPLICATION_MODAL);
        confirmStage.initStyle(StageStyle.UTILITY);
        confirmStage.setTitle("Cancel Confirmation");

        VBox root = new VBox(20);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: #2a0a0a; -fx-border-color: #d4af37; -fx-border-width: 2;");

        Label headerLabel = new Label("Confirm Cancellation");
        headerLabel.setStyle("-fx-text-fill: #FFD700; -fx-font-size: 20px; -fx-font-weight: bold;");

        Label contentLabel = new Label("Are you sure you want to cancel this reservation?\nThis action cannot be undone.");
        contentLabel.setStyle("-fx-text-fill: #fdf5e6; -fx-font-size: 14px; -fx-text-alignment: CENTER;");
        contentLabel.setWrapText(true);

        HBox buttonsBox = new HBox(20);
        buttonsBox.setAlignment(Pos.CENTER);

        Button yesBtn = new Button("Yes, Cancel");
        yesBtn.setStyle("-fx-background-color: #8b0000; -fx-text-fill: white; -fx-font-weight: bold;");
        Button noBtn = new Button("No, Keep it");
        noBtn.setStyle("-fx-background-color: #d4af37; -fx-text-fill: #2a0a0a; -fx-font-weight: bold;");

        final boolean[] result = {false};
        yesBtn.setOnAction(e -> {
            result[0] = true;
            confirmStage.close();
        });
        noBtn.setOnAction(e -> {
            result[0] = false;
            confirmStage.close();
        });

        buttonsBox.getChildren().addAll(yesBtn, noBtn);
        root.getChildren().addAll(headerLabel, contentLabel, buttonsBox);

        Scene scene = new Scene(root, 400, 250);
        confirmStage.setScene(scene);
        confirmStage.setWidth(420);
        confirmStage.setHeight(280);
        confirmStage.showAndWait();

        return result[0];
    }

    private void showQrWindow(String qrData, int reservationId, String customerName, List<String> seats, double total, String paymentMethod, String email, String phone, String reservationSummary, Stage ownerStage) {
        Stage qrStage = new Stage();
        qrStage.initOwner(ownerStage);
        qrStage.initModality(Modality.APPLICATION_MODAL);
        qrStage.setTitle("Ace Theater - Reservation Confirmed");

        BorderPane root = new BorderPane();
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: #2a0a0a; -fx-border-color: #d4af37; -fx-border-width: 2;");

        VBox leftBox = new VBox(10);
        leftBox.setAlignment(Pos.CENTER);
        Label qrTitle = new Label("QR Code");
        qrTitle.setStyle("-fx-text-fill: #fdf5e6; -fx-font-size: 18px;");

        ImageView qrImageView = new ImageView();
        qrImageView.setFitWidth(180); qrImageView.setFitHeight(180); qrImageView.setPreserveRatio(true);

        try {
            String encodedData = URLEncoder.encode(qrData, StandardCharsets.UTF_8.toString());
            String apiUrl = "https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=" + encodedData;
            Image qrImage = new Image(apiUrl, false);
            qrImageView.setImage(qrImage);
        } catch (Exception e) {
            leftBox.getChildren().add(new Label("QR Error"));
        }
        leftBox.getChildren().addAll(qrTitle, qrImageView);

        VBox rightBox = new VBox(8);
        rightBox.setPadding(new Insets(0, 0, 0, 20));
        Label detailsTitle = new Label("Reservation Details");
        detailsTitle.setStyle("-fx-text-fill: #FFD700; -fx-font-size: 22px; -fx-font-family: 'Serif'; -fx-font-weight: bold;");

        String labelStyle = "-fx-text-fill: #fdf5e6; -fx-font-size: 14px;";
        String boldLabelStyle = "-fx-text-fill: #fdf5e6; -fx-font-size: 14px; -fx-font-weight: bold;";

        rightBox.getChildren().addAll(
                detailsTitle,
                createLabel("ID: #" + reservationId, boldLabelStyle),
                createLabel("Name: " + customerName, boldLabelStyle),
                createLabel("Performance: " + performanceName, boldLabelStyle),
                createLabel("Date: " + performanceDate, boldLabelStyle),
                createLabel("Seats: " + String.join(", ", seats), boldLabelStyle),
                createLabel("Total: €" + String.format("%.2f", total), boldLabelStyle),
                createLabel("Payment: " + paymentMethod, labelStyle),
                createLabel("Email: " + email, labelStyle),
                createLabel("Phone: " + phone, labelStyle)
        );

        HBox centerBox = new HBox(20, leftBox, rightBox);
        centerBox.setAlignment(Pos.CENTER);
        root.setCenter(centerBox);

        HBox bottomBox = new HBox(15);
        bottomBox.setAlignment(Pos.CENTER_RIGHT);
        bottomBox.setPadding(new Insets(20, 0, 0, 0));

        Button cancelResBtn = new Button("Cancel Reservation");
        cancelResBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: #ff6b6b; -fx-font-weight: bold; -fx-border-color: #ff6b6b; -fx-border-radius: 5;");
        cancelResBtn.setOnAction(e -> {
            if (showCancelConfirmation()) {
                Set<String> bookedSeats = getBookedSeats();
                for (String seat : seats) bookedSeats.remove(seat);
                MyReservationsController.allReservations.remove(reservationSummary);
                qrStage.close();
                showCustomAlert("Canceled", "Reservation successfully canceled.");
                populateSeatMap();
            }
        });

        Button closeBtn = new Button("Close");
        closeBtn.setStyle("-fx-background-color: #d4af37; -fx-text-fill: #2a0a0a; -fx-font-weight: bold; -fx-background-radius: 5;");
        closeBtn.setOnAction(e -> qrStage.close());

        bottomBox.getChildren().addAll(cancelResBtn, closeBtn);
        root.setBottom(bottomBox);

        Scene scene = new Scene(root, 700, 480);
        qrStage.setScene(scene);
        qrStage.setWidth(720);
        qrStage.setHeight(520);
        qrStage.showAndWait();
    }

    private Label createLabel(String text, String style) {
        Label l = new Label(text);
        l.setStyle(style);
        return l;
    }

    @FXML
    private void onMenuClick(javafx.scene.input.MouseEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(AceTheaterApp.class.getResource("main-menu.fxml"));
        Parent root = loader.load();

        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.setTitle("Ace Theater");
        currentStage.getScene().setRoot(root);
    }

    @FXML
    private void onBackClick(javafx.scene.input.MouseEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(AceTheaterApp.class.getResource("reservation-choice.fxml"));
        Parent root = loader.load();

        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.setTitle("Ace Theater - Reserve Seats");
        currentStage.getScene().setRoot(root);
    }
}
